# -*- coding: utf-8 -*-
"""
Created on Sun Feb 18 23:04:36 2018

@author: User
"""
#%%
import seaborn as sns
from mpl_toolkits.basemap import Basemap
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import requests
import csv
import re
import zipfile
import os

#%%

# Task 1
r = requests.get('https://drive.google.com/uc?export=download&id=0B6ZlG_Eygdj-c1kzcmUxN05VUXM')
with open('Directory.zip', 'wb') as code:
    code.write(r.content)
path = os.getcwd() + '/Directory.zip'
zip_ref = zipfile.ZipFile(path, 'r')
zip_ref.extractall(os.getcwd())
zip_ref.close()

#%%
data = pd.DataFrame.from_csv(path = 'survey_results_public.csv', sep = ',', header = 0, encoding='utf-8' )
print(data.iloc[:,:1].head())
data.shape
#%%
schema = pd.DataFrame.from_csv(path='survey_results_schema.csv', sep = ',', header=0, encoding='utf-8')
schema.head()

#%%

# Task 2

plt.figure(figsize = (25,25))
coord = {'left_lon': -180,'right_lon': 180, 'left_lat': -90, 'right_lat': 90 }
m = Basemap(projection='cyl',llcrnrlat=coord['left_lat'],
            urcrnrlat=coord['right_lat'],
            llcrnrlon=coord['left_lon'], urcrnrlon=coord['right_lon'],resolution='c')

m.drawcoastlines()
m.drawcountries(linewidth=0.25, antialiased = False)
m.fillcontinents(color='peru',lake_color='aqua')

m.drawmapboundary(fill_color='aqua')

plt.title("World map\n", fontsize=18)
plt.show()

#%%

#Task 3 - data preparation

CSV_URL = 'https://developers.google.com/public-data/docs/canonical/countries_csv'
d = pd.read_html(CSV_URL, index_col = 0)[0]
d = d.drop(d[(d[1] == 'latitude')].index)

d[1] = d[1].astype(float)
d[2] = d[2].astype(float)
d = d.dropna()
d3 = d.copy()
d3.rename(columns = {0 : 'name',1 : 'latitude',2: 'longtitude', 3 : 'Country'}, inplace = True)
d3

#%%

#to be continued

plt.figure(figsize = (25,25))
coord = {'left_lon': -180,'right_lon': 180, 'left_lat': -90, 'right_lat': 90 }
m = Basemap(projection='cyl',llcrnrlat=coord['left_lat'],
            urcrnrlat=coord['right_lat'],
            llcrnrlon=coord['left_lon'], urcrnrlon=coord['right_lon'],resolution='c')

m.drawcoastlines()
m.drawcountries(linewidth=0.25, antialiased = False)
m.fillcontinents(color='peru',lake_color='aqua')

m.drawmapboundary(fill_color='aqua')


d = d[(coord['left_lat'] <= d[1]) & (d[1] <= coord['right_lat']) & (coord['left_lon'] <= d[2]) & (d[2] <= coord['right_lon'])]

x1, y1 = m(d[2], d[1])

# s - marker size
m.scatter(x1, y1, marker='o', color='red', s = 100, zorder=10)

for i in range(d.shape[0]):
    plt.text(x1.iloc[i]-6, y1.iloc[i]-2, d.iloc[i][3], fontsize=15)
    
# fontsize - шрифты
  
plt.title("Countries\n", fontsize=18)
plt.show()

#%% 

# Task 4
data = pd.read_csv('survey_results_public.csv')

plt.figure(figsize = (25,25))
coord = {'left_lon': -180,'right_lon': 180, 'left_lat': -90, 'right_lat': 90 }
m = Basemap(projection='cyl',llcrnrlat=coord['left_lat'],
            urcrnrlat=coord['right_lat'],
            llcrnrlon=coord['left_lon'], urcrnrlon=coord['right_lon'],resolution='c')

m.drawcoastlines()
m.drawcountries(linewidth=0.25, antialiased = False)
m.fillcontinents(color='peru',lake_color='aqua')

m.drawmapboundary(fill_color='aqua')

d = d[(coord['left_lat'] <= d[1]) & (d[1] <= coord['right_lat']) & (coord['left_lon'] <= d[2]) & (d[2] <= coord['right_lon'])]
#d = d.dropna()

number = data.groupby(['Country']).count().sort_values(['Respondent'], ascending = False)['Respondent']
Number = pd.DataFrame({'Country' : number.index, 'Total' : number.values}, index = None)

s1 = pd.merge(d3, Number, how='inner', on=['Country'])
#s1 = d3
x1, y1 = m(s1['longtitude'], s1['latitude'])

    
m.scatter(x1, y1, marker='o', color='red', s = s1['Total'] / 20, zorder=10)

for i in range(s1.shape[0]):
    plt.text(x1.iloc[i]-6, y1.iloc[i]-5, s1.iloc[i]['Country'], fontsize=15)
    
# fontsize - шрифты
  
plt.title("Countries\n", fontsize=18)
plt.show()

#%%

#Task 2

# Task 1
zf = zipfile.ZipFile('railways.zip')
zf.namelist()
zf.extractall(os.getcwd())
zf.close()

#%%
railways = pd.DataFrame.from_csv(path='railways201208.csv', sep = ',', header = 0, index_col = 1, encoding='utf-8')

#%%
railways[['date_priem', 'sto_code', 'stn_code', 'dist']].head()
#%%
stations = pd.DataFrame.from_csv(path='stations.csv', sep = ',', header=0, index_col = 1, encoding='utf-8')
#%%
stations[['stshortname',  'stcode']].head()
#%%

# Task 2
railways['log_dist'] = np.log(railways['dist'])

sns.distplot(railways['log_dist'],bins=np.linspace(0 , 10 , 100) ,
             kde_kws = {'color' : 'limegreen' ,'label': 'log Distance'},
             hist_kws = {'color':'royalblue', 'alpha':None}, axlabel = '$log(Distance)$')
plt.show()
#%%
sns.distplot(railways['dist'],
             kde_kws = {'color' : 'limegreen' ,'label': 'log Distance'},
             hist_kws = {'color':'royalblue', 'alpha':None}, axlabel = '$log(Distance)$')
plt.show()
#%% 
# Task 3 - version 1

box = pd.DataFrame(columns = ['Coal'])

box['Coal'] = railways[railways['commodity'] == 1]['log_dist']

box = pd.concat([box, railways[railways['commodity'] == 2]['log_dist']], axis = 0, ignore_index = True)
box.rename(columns = {'Coal' : 'Coal', 0 : 'Oil'}, inplace = True)

box = pd.concat([box, railways[railways['commodity'] == 3]['log_dist']], axis = 0, ignore_index = True)
box.rename(columns = {'Coal' : 'Coal', 0 : 'Ores'}, inplace = True)

box = pd.concat([box, railways[railways['commodity'] == 4]['log_dist']], axis = 0, ignore_index = True)
box.rename(columns = {'Coal' : 'Coal', 0 : 'Metals'}, inplace = True)

box = pd.concat([box, railways[railways['commodity'] == 5]['log_dist']], axis = 0, ignore_index = True)
box.rename(columns = {'Coal' : 'Coal', 0 : 'Wood'}, inplace = True)

box = pd.concat([box, railways[railways['commodity'] == 6]['log_dist']], axis = 0, ignore_index = True)
box.rename(columns = {'Coal' : 'Coal', 0 : 'Constructions'}, inplace = True)

box = pd.concat([box, railways[railways['commodity'] == 7]['log_dist']], axis = 0, ignore_index = True)
box.rename(columns = {'Coal' : 'Coal', 0 : 'Fertilizers'}, inplace = True)

box = pd.concat([box, railways[railways['commodity'] == 8]['log_dist']], axis = 0, ignore_index = True)
box.rename(columns = {'Coal' : 'Coal', 0 : 'Grains'}, inplace = True)

box = pd.concat([box, railways[railways['commodity'] == 9]['log_dist']], axis = 0, ignore_index = True)
box.rename(columns = {'Coal' : 'Coal', 0 : 'Petrol'}, inplace = True)

box = pd.concat([box, railways[railways['commodity'] == 10]['log_dist']], axis = 0, ignore_index = True)
box.rename(columns = {'Coal' : 'Coal', 0 : 'Others'}, inplace = True)

ax = plt.axes()

sns.boxplot(box, ax = ax)
ax.set_xlabel('Commodity type')
ax.set_ylabel('$log$ Distance')
plt.xticks(rotation = 'vertical')
plt.show()
#%%

# Task 3 - version 2
box = pd.DataFrame()
box['Coal'] = railways[railways['commodity'] == 1]['log_dist']
for i in range(2,11):
    box = pd.concat([box, railways[railways['commodity'] == i]['log_dist']], 
                    axis = 0, ignore_index = True)
    box.rename(columns = {'Coal' : 'Coal' , 0 : i}, inplace = True)

ax = plt.axes()

sns.boxplot(box, ax = ax)
ax.set_xlabel('Commodity type')
ax.set_ylabel('log Distance',  family = 'cursive')
ax.set_xticklabels( ['Coal', 'Oil', 'Ores', 'Metals', 'Wood', 'Constructions', 
                     'Fertilizers' , 'Grains' , 'Petrol', 'Others'], rotation = 90 )
plt.show()
#%%

# Task 4

box = pd.DataFrame(columns = ['Commodity type', 'log Distance', 'Weight'])
box['Commodity type'] = railways['commodity'].replace(to_replace = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10], 
        value = ['Coal', 'Oil', 'Ores', 'Metals', 'Woods', 'Constructions', 'Fertilizers', 'Grains',
                 'Petrol', 'Others'])

box['log Distance'] = railways['log_dist']

#upper = 20000
#lower = 5000

#railways.drop(railways[(railways['weight'] > lower) & (railways['weight']< upper)].index, inplace=True)


l = pd.DataFrame()
l['flag'] = railways['weight'] < railways['weight'].median()
l = l.replace(to_replace=[True, False], value=['Light', 'Heavy'])

box['Weight'] = l
ax = plt.axes()
sns.violinplot(data = box, x = 'Commodity type', y = 'log Distance', hue = 'Weight', split = True,
               order = ['Coal', 'Oil', 'Ores', 'Metals', 'Woods', 'Constructions', 
                     'Fertilizers' , 'Grains' , 'Petrol', 'Others'], ax = ax, hue_order= ['Light', 'Heavy'])
ax.set_xticklabels( ['Coal', 'Oil', 'Ores', 'Metals', 'Wood', 'Constructions', 
                     'Fertilizers' , 'Grains' , 'Petrol', 'Others'], rotation = 90 )
plt.show()

#%% 

# Task 5

# выкидываем те наблюдения, для которых amount = 0, так как они не несут статистического смысла

railways.drop(railways[railways['amount'] == 0].index, inplace = True)
railways['log_amount'] = np.log(railways['amount'])

railways['proizved'] = np.log(railways['weight'] * railways['dist'])

g = sns.jointplot(x='proizved',
              y='log_amount', data = railways, kind = 'reg', marginal_kws={'hist_kws': {'edgecolor': "black"}})#kind можно прописывать разным. Например, 'hex', 'kde'

g.fig.set_figwidth(10)
g.fig.set_figheight(10)

g.set_axis_labels("$log(weight*dist)$", "$log(amount)$");
plt.show()
#%%